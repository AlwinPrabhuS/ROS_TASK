# Task 1 - Differential Drive Robot Simulation in Gazebo

## 🧰 Prerequisites
- ROS 2 Humble installed
- Gazebo (gzclient/gzserver)
- Packages: `gazebo_ros`, `robot_state_publisher`, `xacro`, `urdf`

## 📦 Package Structure
```
my_robot_pkg/
├── launch/
│   └── spawn_robot.launch.py
└── urdf/
    └── my_robot.urdf.xacro
```

## 🔨 Build Instructions
```bash
cd ~/ros2_ws
colcon build --symlink-install
source install/setup.bash
```

## 🚀 Launch Simulation
```bash
ros2 launch my_robot_pkg spawn_robot.launch.py
```

## ✅ Verify Topics
After launching, run:
```bash
ros2 topic list
```

Expected topics:
- `/scan`
- `/imu/data`
- `/cmd_vel`
- `/odom`
- `/tf`, `/tf_static`
- `/robot_description`

---

# Task 2 - Custom Message and Subscriber Node

## 🧰 Prerequisites
- ROS 2 Humble installed

## 📦 Directory Structure
```
ros2_ws/src/
├── training/
│   └── training/subscriber_node.py
├── training_interfaces/
│   └── msg/Person.msg
```

## 🔤 Message Definition
**File:** `training_interfaces/msg/Person.msg`
```msg
string name
int32 age
float32 height
```

## 🔧 CMakeLists.txt & package.xml
Ensure both `training_interfaces` and `training` have proper dependencies set:
- `rosidl_default_generators` in `training_interfaces`
- Add `training_interfaces` as a dependency in `training`

## 🔨 Build Instructions
```bash
cd ~/ros2_ws
colcon build --symlink-install
source install/setup.bash
```

## 🚀 Run Subscriber Node
```bash
ros2 run training subscriber_node
```

## 🧪 Test
In a new terminal:
```bash
ros2 topic pub /person training_interfaces/Person "{name: 'Alice', age: 25, height: 5.4}"
```

You should see the message echoed by the subscriber.