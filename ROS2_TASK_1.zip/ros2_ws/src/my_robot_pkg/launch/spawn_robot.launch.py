from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess
from launch.substitutions import Command

def generate_launch_description():
    return LaunchDescription([
        # Launch Gazebo with factory
        ExecuteProcess(
            cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_factory.so'],
            output='screen'
        ),

        # robot_state_publisher with xacro
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[{
                'robot_description': Command(['xacro ', '/home/user/ros2_ws/src/my_robot_pkg/urdf/my_robot.urdf.xacro'])
            }],
            output='screen'
        ),

        # Spawn robot
        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            arguments=[
                '-entity', 'my_robot',
                '-file', '/home/user/ros2_ws/src/my_robot_pkg/urdf/my_robot.urdf.xacro',
                '-z', '0.3'
            ],
            output='screen'
        )
    ])
