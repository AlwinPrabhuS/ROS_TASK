import rclpy
from rclpy.node import Node
from training_interfaces.srv import Value

class ValueClient(Node):
    def __init__(self):
        super().__init__('value_client')
        self.cli = self.create_client(Value, 'compute_sum')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for service...')
        self.send_request()

    def send_request(self):
        req = Value.Request()
        req.a = 5
        req.b = 10
        future = self.cli.call_async(req)
        rclpy.spin_until_future_complete(self, future)
        if future.result():
            self.get_logger().info(f'Result: {future.result().val}')
        else:
            self.get_logger().error('Service call failed.')

def main(args=None):
    rclpy.init(args=args)
    node = ValueClient()
    node.destroy_node()
    rclpy.shutdown()
