import rclpy
from rclpy.node import Node
from training_interfaces.srv import Value

class ValueService(Node):
    def __init__(self):
        super().__init__('value_service')
        self.srv = self.create_service(Value, 'compute_sum', self.callback)

    def callback(self, request, response):
        response.val = request.a + request.b
        self.get_logger().info(f"Received: a={request.a}, b={request.b} → sum={response.val}")
        return response

def main(args=None):
    rclpy.init(args=args)
    node = ValueService()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
