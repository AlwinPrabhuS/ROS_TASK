import rclpy
from rclpy.node import Node
from training_interfaces.msg import Person

class PersonPublisher(Node):
    def __init__(self):
        super().__init__('person_publisher')
        self.publisher_ = self.create_publisher(Person, 'person_topic', 10)
        self.timer = self.create_timer(1.0, self.publish_person)
        self.count = 0

    def publish_person(self):
        msg = Person()
        msg.name = f'Person {self.count}'
        msg.age = 20 + self.count
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing: {msg.name}, {msg.age}')
        self.count += 1

def main(args=None):
    rclpy.init(args=args)
    node = PersonPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
